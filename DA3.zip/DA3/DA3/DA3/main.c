#define F_CPU 16000000UL //16 Mhz.
#define BAUD 9600	//Set Baud rate 9600.
#define MYUBRR F_CPU/16/BAUD-1
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <avr/interrupt.h>

void read_adc(void);
void adc_init(void);
void USART_init(unsigned int ubrr);
void USART_tx_string(char *data);

volatile unsigned int adc_temp;
char outs[20];

ISR(TIMER1_OVF_vect)
{
	read_adc();
	snprintf(outs, sizeof(outs), "%3d\r\n", adc_temp);	//output the degrees.
	USART_tx_string(outs);

	_delay_ms(100);

	TCNT1 = 0xC2f7 	;			//reset the TCNT1 counter
}

int main(void)
{
	adc_init();	//Initiate ADC.
	USART_init(MYUBRR);					//initiate USART using MYUBRR config
	USART_tx_string("Connected!\r\n");

	_delay_ms(100);
	
	sei();							//enable interrupts
	
	while(1)
	{
	}
}

void adc_init(void)
{
	ADMUX = 0x40;
	//setting REFS0 to 1 enables AVcc external cap at AREF
	
	ADCSRA = 0x85;
	//sending one to ADEN enables ADC. The last three set the prescaler
	
	TIMSK1 |= (1<<TOIE1);					//enable overflow interrupt.
	TCCR1B |= (1<<CS12)| (1<<CS10) ;				//native clock
	TCNT1 = 0b1100001011110111; 				//delay for 1 second
}

void read_adc(void)
{
	unsigned char i = 4;
	adc_temp = 0;

	while(i--)
	{
		ADCSRA |= (1<<ADSC);
		while(ADCSRA & (1<<ADSC));
		adc_temp+=ADC;
		_delay_ms(50);
	}
	adc_temp = adc_temp / 4;				//average samples
}

void USART_init(unsigned int ubrr)
{
	UBRR0H = (unsigned char)(ubrr>>8);
	UBRR0L = (unsigned char)ubrr;
	UCSR0B = (1<<TXEN0);					//enable receiver, transmitter & rx interrupt.
	UCSR0C = (3<<UCSZ00);  					//asynchronous 8 N 1
}

void USART_tx_string(char *data)
{
	while(*data != '\0')
	{
		while(!(UCSR0A & (1<<UDRE0)));

		UDR0 = *data;
		data++;
	}
}



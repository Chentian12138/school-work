
#include <avr/io.h>
int main()
{
	DDRB = 0xFF; //set register B for output
	PORTB = 0x00; //init port b
	TCCR1B = 0b00001101; //set prescaler to 1024 and fast PWM
	TCCR1A = 0b00000001; //set fast PWM
	
	OCR1B = 512; //50% duty cycle
	
	while(1)
	{
		if(TCNT1 == 243) //check for when counter hits 243 (generates .5 period)
		{
			PORTB ^= 0b00000100; //toggle my LED at PB2
			TCNT1 =0x00; //reset counter
		}
	}
}

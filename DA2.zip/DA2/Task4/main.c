#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

ISR(TIMER0_OVF_vect)
{
	PORTB ^= 255;
	TCNT0 = 11;
}

int main()
{
	DDRB = 0b00000100;
	TIMSK0 = (1 << TOIE1);
	TCCR0B = 13;
	TCCR0A = 1;
	TCNT0 = 11;

	sei();
	while(1)
	{
	}
}

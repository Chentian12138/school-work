#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

ISR(INT0_vect)
{
	PORTB = 4;
	_delay_ms(1000);
	PORTB = 0;
}

int main()
{
	DDRB = 4;
	EIMSK = EIFR = 1;
	EICRA = 3;
	
	sei();
	while(1)
	{

	}
}

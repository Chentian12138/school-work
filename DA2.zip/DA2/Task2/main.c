#include <avr/io.h>
#include <util/delay.h>

int main()
{
	DDRB = 4;
	DDRD = 0;
	while(1)
	{
		if((PIND&4) == 4)
		{
			PORTB = 4;
			_delay_ms(1000);
			PORTB = 0;

			while((PIND&4) == 4)
			{

			}
		}
		else
			PORTB = 0;
	}
}

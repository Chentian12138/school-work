#include <avr/io.h>
int main()
{
	DDRB = 0xFF; //set register B for output
	PORTB = 0x00; //init port b
	TCCR0B = 0x0D; //set prescaler to 1024 and fast PWM
	TCCR0A = 0x01; //set fast PWM

	OCR0B = 512; //50% duty cycle

	while(1)
	{
		if(TCNT0 == 243) //check for when counter hits 243 (generates .5 period)
		{
			PORTB ^= 0x04; //toggle my LED at PB2
			TCNT0 = 0x00; //reset counter
		}
	}
}
